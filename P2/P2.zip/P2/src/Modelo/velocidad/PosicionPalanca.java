package Modelo.velocidad;

public enum PosicionPalanca {
    APAGAR,
    ACELERAR,
    MANTENER,
    REINICIAR
}

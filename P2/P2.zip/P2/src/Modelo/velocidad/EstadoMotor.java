package Modelo.velocidad;

public enum EstadoMotor {
    APAGADO,
    ENCENDIDO,
    ACELERANDO,
    FRENANDO,
    MANTENIENDO
}

package Modelo.velocidad;

public enum Componentes {
    PALANCA,
    PEDALES
}
